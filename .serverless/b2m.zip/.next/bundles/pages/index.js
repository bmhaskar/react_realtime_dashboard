
          window.__NEXT_REGISTER_PAGE('/', function() {
            var comp = module.exports=webpackJsonp([2],[],[260]);
            return { page: comp.default }
          })
        